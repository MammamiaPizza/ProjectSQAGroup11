package org.jfree.data.general.junit;

import java.util.Arrays;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.function.Function2D;
import org.jfree.data.general.AbstractDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.pie.DefaultPieDataset;
import org.jfree.data.pie.PieDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class DatasetUtilitiesGeneratedTest {

    private static final double EPSILON = 0.0000001;

    @Test
    public void testCalculatePieDatasetTotalIgnoresNullZeroAndNegativeValues() {
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("positive-1", Double.valueOf(2.5));
        dataset.setValue("positive-2", Double.valueOf(3.5));
        dataset.setValue("zero", Double.valueOf(0.0));
        dataset.setValue("negative", Double.valueOf(-4.0));
        dataset.setValue("null", null);

        assertEquals(6.0, DatasetUtilities.calculatePieDatasetTotal(dataset),
                EPSILON);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCalculatePieDatasetTotalRejectsNullDataset() {
        DatasetUtilities.calculatePieDatasetTotal(null);
    }

    @Test
    public void testCreatePieDatasetsForRowAndColumnCopyExpectedKeysAndValues() {
        DefaultCategoryDataset source = new DefaultCategoryDataset();
        source.addValue(Double.valueOf(1.0), "R1", "C1");
        source.addValue(Double.valueOf(2.0), "R1", "C2");
        source.addValue(Double.valueOf(3.0), "R2", "C1");
        source.addValue(Double.valueOf(4.0), "R2", "C2");

        PieDataset rowPie = DatasetUtilities.createPieDatasetForRow(source,
                "R1");
        assertEquals(2, rowPie.getItemCount());
        assertEquals(1.0, rowPie.getValue("C1").doubleValue(), EPSILON);
        assertEquals(2.0, rowPie.getValue("C2").doubleValue(), EPSILON);

        PieDataset columnPie = DatasetUtilities.createPieDatasetForColumn(
                source, 1);
        assertEquals(2, columnPie.getItemCount());
        assertEquals(2.0, columnPie.getValue("R1").doubleValue(), EPSILON);
        assertEquals(4.0, columnPie.getValue("R2").doubleValue(), EPSILON);
    }

    @Test
    public void testCreateConsolidatedPieDatasetAggregatesOnlyWhenMinimumCountMet() {
        DefaultPieDataset source = new DefaultPieDataset();
        source.setValue("large", Double.valueOf(80.0));
        source.setValue("small-1", Double.valueOf(10.0));
        source.setValue("small-2", Double.valueOf(5.0));

        PieDataset result = DatasetUtilities.createConsolidatedPieDataset(
                source, "Other", 0.15, 2);

        assertEquals(2, result.getItemCount());
        assertEquals(80.0, result.getValue("large").doubleValue(), EPSILON);
        assertEquals(15.0, result.getValue("Other").doubleValue(), EPSILON);
        assertNull(result.getValue("small-1"));
        assertNull(result.getValue("small-2"));
    }

    @Test
    public void testCreateCategoryDatasetWithExplicitKeysCopiesRaggedData() {
        Comparable[] rowKeys = new Comparable[] {"R1", "R2"};
        Comparable[] columnKeys = new Comparable[] {"C1", "C2"};
        double[][] data = new double[][] {
            {1.0, 2.0},
            {3.0}
        };

        CategoryDataset result = DatasetUtilities.createCategoryDataset(
                rowKeys, columnKeys, data);

        assertEquals(2, result.getRowCount());
        assertEquals(2, result.getColumnCount());
        assertEquals(1.0, result.getValue("R1", "C1").doubleValue(), EPSILON);
        assertEquals(2.0, result.getValue("R1", "C2").doubleValue(), EPSILON);
        assertEquals(3.0, result.getValue("R2", "C1").doubleValue(), EPSILON);
        assertNull(result.getValue("R2", "C2"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateCategoryDatasetRejectsDuplicateRowKeys() {
        DatasetUtilities.createCategoryDataset(
                new Comparable[] {"R1", "R1"},
                new Comparable[] {"C1"},
                new double[][] {{1.0}, {2.0}});
    }

    @Test
    public void testSampleFunction2DToSeriesIncludesBothEndpoints() {
        Function2D square = new Function2D() {
            public double getValue(double x) {
                return x * x;
            }
        };

        XYSeries result = DatasetUtilities.sampleFunction2DToSeries(
                square, 0.0, 2.0, 3, "square");

        assertEquals(3, result.getItemCount());
        assertEquals(0.0, result.getX(0).doubleValue(), EPSILON);
        assertEquals(0.0, result.getY(0).doubleValue(), EPSILON);
        assertEquals(1.0, result.getX(1).doubleValue(), EPSILON);
        assertEquals(1.0, result.getY(1).doubleValue(), EPSILON);
        assertEquals(2.0, result.getX(2).doubleValue(), EPSILON);
        assertEquals(4.0, result.getY(2).doubleValue(), EPSILON);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSampleFunction2DToSeriesRejectsInsufficientSamples() {
        DatasetUtilities.sampleFunction2DToSeries(new Function2D() {
            public double getValue(double x) {
                return x;
            }
        }, 0.0, 1.0, 1, "series");
    }

    @Test
    public void testIsEmptyOrNullRecognizesNullAndNonEmptyDatasets() {
        assertTrue(DatasetUtilities.isEmptyOrNull((PieDataset) null));
        assertTrue(DatasetUtilities.isEmptyOrNull((CategoryDataset) null));

        DefaultPieDataset pie = new DefaultPieDataset();
        pie.setValue("negative", Double.valueOf(-1.0));
        pie.setValue("zero", Double.valueOf(0.0));
        assertTrue(DatasetUtilities.isEmptyOrNull(pie));

        pie.setValue("positive", Double.valueOf(0.1));
        assertFalse(DatasetUtilities.isEmptyOrNull(pie));

        DefaultCategoryDataset category = new DefaultCategoryDataset();
        category.addValue(null, "R1", "C1");
        assertTrue(DatasetUtilities.isEmptyOrNull(category));

        category.setValue(Double.valueOf(0.0), "R1", "C1");
        assertFalse(DatasetUtilities.isEmptyOrNull(category));
    }

    @Test
    public void testIterateRangeBoundsIgnoresNullAndNaNCategoryValues() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(Double.valueOf(-2.0), "R1", "C1");
        dataset.addValue(Double.valueOf(Double.NaN), "R1", "C2");
        dataset.addValue(null, "R1", "C3");
        dataset.addValue(Double.valueOf(5.0), "R2", "C1");

        Range range = DatasetUtilities.iterateRangeBounds(dataset, false);

        assertEquals(-2.0, range.getLowerBound(), EPSILON);
        assertEquals(5.0, range.getUpperBound(), EPSILON);
    }

    @Test
    public void testVisibleIntervalCategoryRangeIncludesCentralValueWhenEndpointsAreNull() {
        IntervalCategoryDataset dataset = new SimpleIntervalCategoryDataset(
                new Comparable[] {"visible", "hidden"},
                new Comparable[] {"C1"},
                new Number[][] {
                    {Double.valueOf(100.0)},
                    {Double.valueOf(-1000.0)}
                },
                new Number[][] {
                    {null},
                    {Double.valueOf(-1100.0)}
                },
                new Number[][] {
                    {null},
                    {Double.valueOf(-900.0)}
                });

        Range range = DatasetUtilities.iterateToFindRangeBounds(dataset,
                Arrays.asList(new Comparable[] {"visible"}), true);

        assertEquals(100.0, range.getLowerBound(), EPSILON);
        assertEquals(100.0, range.getUpperBound(), EPSILON);
    }

    @Test
    public void testVisibleCategoryRangeExcludesHiddenSeries() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(Double.valueOf(4.0), "visible", "C1");
        dataset.addValue(Double.valueOf(8.0), "visible", "C2");
        dataset.addValue(Double.valueOf(-50.0), "hidden", "C1");

        Range range = DatasetUtilities.findRangeBounds(dataset,
                Arrays.asList(new Comparable[] {"visible"}), false);

        assertEquals(4.0, range.getLowerBound(), EPSILON);
        assertEquals(8.0, range.getUpperBound(), EPSILON);
    }

    @Test
    public void testDomainAndRangeBoundsForXYDatasetIgnoreNaNValues() {
        XYSeries series = new XYSeries("S1");
        series.add(1.0, Double.NaN);
        series.add(2.0, -3.0);
        series.add(4.0, 5.0);
        XYSeriesCollection dataset = new XYSeriesCollection(series);

        Range domain = DatasetUtilities.iterateDomainBounds(dataset, false);
        Range range = DatasetUtilities.iterateRangeBounds(dataset, false);

        assertEquals(1.0, domain.getLowerBound(), EPSILON);
        assertEquals(4.0, domain.getUpperBound(), EPSILON);
        assertEquals(-3.0, range.getLowerBound(), EPSILON);
        assertEquals(5.0, range.getUpperBound(), EPSILON);
    }

    @Test
    public void testFindStackedAndCumulativeRangeBounds() {
        DefaultCategoryDataset stacked = new DefaultCategoryDataset();
        stacked.addValue(Double.valueOf(2.0), "R1", "C1");
        stacked.addValue(Double.valueOf(-3.0), "R1", "C2");
        stacked.addValue(Double.valueOf(4.0), "R2", "C1");
        stacked.addValue(Double.valueOf(-1.0), "R2", "C2");

        Range stackedRange = DatasetUtilities.findStackedRangeBounds(stacked);
        assertEquals(-4.0, stackedRange.getLowerBound(), EPSILON);
        assertEquals(6.0, stackedRange.getUpperBound(), EPSILON);

        DefaultCategoryDataset cumulative = new DefaultCategoryDataset();
        cumulative.addValue(Double.valueOf(3.0), "R1", "C1");
        cumulative.addValue(Double.valueOf(-5.0), "R1", "C2");
        cumulative.addValue(Double.valueOf(2.0), "R1", "C3");

        Range cumulativeRange = DatasetUtilities.findCumulativeRangeBounds(
                cumulative);
        assertEquals(-2.0, cumulativeRange.getLowerBound(), EPSILON);
        assertEquals(3.0, cumulativeRange.getUpperBound(), EPSILON);
    }

    /**
     * A small IntervalCategoryDataset implementation used to exercise the
     * IntervalCategoryDataset-specific branch without relying on unrelated
     * dataset implementations.
     */
    private static class SimpleIntervalCategoryDataset extends AbstractDataset
            implements IntervalCategoryDataset {

        private Comparable[] rowKeys;
        private Comparable[] columnKeys;
        private Number[][] values;
        private Number[][] starts;
        private Number[][] ends;

        SimpleIntervalCategoryDataset(Comparable[] rowKeys,
                Comparable[] columnKeys, Number[][] values,
                Number[][] starts, Number[][] ends) {
            this.rowKeys = rowKeys;
            this.columnKeys = columnKeys;
            this.values = values;
            this.starts = starts;
            this.ends = ends;
        }

        public int getRowCount() {
            return this.rowKeys.length;
        }

        public int getColumnCount() {
            return this.columnKeys.length;
        }

        public List getRowKeys() {
            return Arrays.asList(this.rowKeys);
        }

        public List getColumnKeys() {
            return Arrays.asList(this.columnKeys);
        }

        public Comparable getRowKey(int row) {
            return this.rowKeys[row];
        }

        public int getRowIndex(Comparable key) {
            return indexOf(this.rowKeys, key);
        }

        public Comparable getColumnKey(int column) {
            return this.columnKeys[column];
        }

        public int getColumnIndex(Comparable key) {
            return indexOf(this.columnKeys, key);
        }

        public Number getValue(int row, int column) {
            return this.values[row][column];
        }

        public Number getValue(Comparable rowKey, Comparable columnKey) {
            int row = getRowIndex(rowKey);
            int column = getColumnIndex(columnKey);
            return row >= 0 && column >= 0 ? getValue(row, column) : null;
        }

        public Number getStartValue(int row, int column) {
            return this.starts[row][column];
        }

        public Number getStartValue(Comparable rowKey, Comparable columnKey) {
            int row = getRowIndex(rowKey);
            int column = getColumnIndex(columnKey);
            return row >= 0 && column >= 0 ? getStartValue(row, column) : null;
        }

        public Number getEndValue(int row, int column) {
            return this.ends[row][column];
        }

        public Number getEndValue(Comparable rowKey, Comparable columnKey) {
            int row = getRowIndex(rowKey);
            int column = getColumnIndex(columnKey);
            return row >= 0 && column >= 0 ? getEndValue(row, column) : null;
        }

        private int indexOf(Comparable[] keys, Comparable key) {
            for (int i = 0; i < keys.length; i++) {
                if (keys[i].equals(key)) {
                    return i;
                }
            }
            return -1;
        }
    }
}
